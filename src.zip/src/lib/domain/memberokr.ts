/**
 * ==========================================================
 * CascadEffects Performance Platform
 * Member OKR Domain
 * ----------------------------------------------------------
 * Persistent employee performance data.
 *
 * Ownership:
 *
 * Organization Membership
 *        ↓
 * Member Objective
 *        ↓
 * Member Key Result
 *        ↓
 * Member Initiative
 *
 * IMPORTANT:
 *
 * This is NOT Runtime.
 *
 * Runtime owns monthly execution and historical snapshots.
 *
 * This domain owns the member's persistent Objectives,
 * Key Results, and Initiatives.
 *
 * Performance Builder does not own these records.
 * Assignment does not own these records.
 * ==========================================================
 */

/* ==========================================================
   Member Objective
========================================================== */

export interface MemberObjective {
  id: string;

  organizationMembershipId: string;

  title: string;

  description?: string;

  weight?: number;

  /*
   * Visibility is separate from the Objective's content and
   * from the visibility state of its individual Key Results.
   *
   * Hidden means the Objective is no longer shown in the
   * member's current active Objective list.
   *
   * The Objective itself remains stored so that its complete
   * Objective and Key Result configuration can be recovered
   * and the Objective can be activated again.
   *
   * Hiding an Objective does NOT change the isHidden state of
   * any Key Results belonging to that Objective.
   */
  isHidden: boolean;

  position: number;

  createdAt: string;

  updatedAt: string;

  keyResults: MemberKeyResult[];
}

/* ==========================================================
   Member Key Result
========================================================== */

export type MemberKeyResultMeasurementType =
  | "percentage"
  | "numeric"
  | "financial";

export type MemberKeyResultScoringMethod =
  | "percent_into_period"
  | "percentage_of_target"
  | "display_only";

export type MemberKeyResultStatus =
  | "active"
  | "completed"
  | "cancelled";

export interface MemberKeyResult {
  id: string;

  memberObjectiveId: string;

  title: string;

  target: unknown;

  currentValue: unknown;

  weight?: number;

  measurementType?: MemberKeyResultMeasurementType;

  scoringMethod?: MemberKeyResultScoringMethod;

  status: MemberKeyResultStatus;

  /*
   * Visibility is separate from status.
   *
   * Hidden means the Key Result is no longer shown
   * in the member's current active Key Result list.
   *
   * The Key Result itself remains stored so that its
   * historical relationships and Runtime records remain
   * intact and the Key Result can be activated again.
   */
  isHidden: boolean;

  position: number;

  createdAt: string;

  updatedAt: string;

  initiatives: MemberInitiative[];
}

/* ==========================================================
   Member Initiative
========================================================== */

export interface MemberInitiative {
  id: string;

  memberKeyResultId: string;

  text: string;

  position: number;

  createdAt: string;

  updatedAt: string;
}

/* ==========================================================
   Create Objective
========================================================== */

export interface CreateMemberObjectiveInput {
  organizationMembershipId: string;

  title: string;

  description?: string;

  weight?: number;

  position?: number;
}

/* ==========================================================
   Update Objective
========================================================== */

export interface UpdateMemberObjectiveInput {
  objectiveId: string;

  title: string;

  description?: string;

  weight?: number;

  position?: number;
}

/* ==========================================================
   Create Key Result
========================================================== */

export interface CreateMemberKeyResultInput {
  memberObjectiveId: string;

  title: string;

  target?: unknown;

  currentValue?: unknown;

  weight?: number;

  measurementType?:
    | MemberKeyResultMeasurementType;

  scoringMethod?:
    | MemberKeyResultScoringMethod;

  status?: MemberKeyResultStatus;

  position?: number;
}

/* ==========================================================
   Update Key Result
========================================================== */

export interface UpdateMemberKeyResultInput {
  keyResultId: string;

  title: string;

  target?: unknown;

  currentValue?: unknown;

  weight?: number;

  measurementType?:
    | MemberKeyResultMeasurementType;

  scoringMethod?: MemberKeyResultScoringMethod;

  status?: MemberKeyResultStatus;

  position?: number;
}

/* ==========================================================
   Create Initiative
========================================================== */

export interface CreateMemberInitiativeInput {
  memberKeyResultId: string;

  text: string;

  position?: number;
}

/* ==========================================================
   Update Initiative
========================================================== */

export interface UpdateMemberInitiativeInput {
  initiativeId: string;

  text: string;

  position?: number;
}